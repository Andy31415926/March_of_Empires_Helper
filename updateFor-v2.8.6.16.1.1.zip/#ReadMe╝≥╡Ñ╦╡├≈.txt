﻿Run game helper:run the program
Setting: Setting the program whis visualization tools
Expert:Setting the program whis notepad2
There should not be any space in the program path, which will result in failure to start.
============== Chinese ==========================
Run game helper:运行辅助
Setting：设置辅助参数
Expert：专家模式辅助参数
程序解压的文件和上级文件夹不应该有空格,否则会导致无法启动